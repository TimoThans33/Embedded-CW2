#include "HashAlgorithm.h"

HashAlgorithm::~HashAlgorithm()
{
}
