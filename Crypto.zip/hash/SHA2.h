#ifndef SHA2_H
#define SHA2_H

#include "SHA224.h"
#include "SHA256.h"
#include "SHA384.h"
#include "SHA512.h"

#endif
